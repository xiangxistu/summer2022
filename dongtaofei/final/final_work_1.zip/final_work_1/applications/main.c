#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "sensor_inven_mpu6xxx.h"
#include "stdio.h"
#include "math.h"
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
//#include <rtdbg.h>

#define  LED2_PIN    GET_PIN(E, 6)  //led PIN����
#define MPU6050_I2C_BUS_NAME          "i2c1"      //i2c�����豸��
#define MPU6050_ADDR                  0x68        //MPU6050��ַ���ȶ���
struct mpu6xxx_device *i2c_bus;     //6050���ƾ��
struct mpu6xxx_3axes gyro1, accel1;     //�����ǣ����ٶȽṹ��
int16_t gyro2,gyro3,gyro4,accel2,accel3,accel4;//����ڵ�XYZ����
int16_t AW,BW,AW_1,BW_1,CHA_AW = 0,CHA_BW = 0;//������
int16_t light_flag = 0;////�Ƶ�FLAG
static rt_sem_t LED_sem = 0;//�ź���


/* �߳�6050 */
void thread_6050_entry(void)
{
    i2c_bus = (struct mpu6xxx_device *)mpu6xxx_init(MPU6050_I2C_BUS_NAME, MPU6050_ADDR);   //��ʼ��MPU6050��������λΪ���ٶȣ����ٶ�    while(count++)
    mpu6xxx_set_param(i2c_bus, MPU6XXX_ACCEL_RANGE, MPU6XXX_GYRO_RANGE_250DPS);  //�����Ƿ�Χ����
    mpu6xxx_set_param(i2c_bus, MPU6XXX_ACCEL_RANGE, MPU6XXX_ACCEL_RANGE_2G);     //���ٶȼ�
    mpu6xxx_set_param(i2c_bus, MPU6XXX_DLPF_CONFIG, MPU6XXX_DLPF_188HZ);        //��ͨ�˲�
    mpu6xxx_set_param(i2c_bus, MPU6XXX_SAMPLE_RATE, 500);                       //����Ƶ��
}

//static void rt_LED_entry(void *parameter)
//{
//    static rt_err_t result;
//    while (1)
//    {
//        /* ���÷�ʽ�ȴ��ź�������ȡ���ź�������ִ��number�ԼӵĲ��� */
//        result = rt_sem_take(LED_sem, RT_WAITING_FOREVER);
//        if (result != RT_EOK)
//        {
//            rt_kprintf("thread2 take a dynamic semaphore, failed.\n");
//            rt_sem_delete(LED_sem);
//            return;
//        }
//        else
//        {
//
//        }
//    }
//}

static void rt_LED_entry(void *parameter)
{
    rt_pin_write(LED2_PIN, PIN_LOW);
    static rt_err_t result;
    /*���÷�ʽ�ȴ��ź�������ȡ���ź���*/
    result = rt_sem_take(LED_sem, RT_WAITING_FOREVER);
    if (result != RT_EOK)
    {
        rt_kprintf("thread2 take a dynamic semaphore, failed.\n");
        rt_sem_delete(LED_sem);
        return;
    }
    else
    {

        rt_kprintf("thread2 take a dynamic semaphore, succeed");

    }
}


int main(void)
{
    int count = 1;
    LED_sem = rt_sem_create("dsem", 0, RT_IPC_FLAG_FIFO);//����LED_sem�ź���
    if (LED_sem == RT_NULL)
       {
           rt_kprintf("create dynamic semaphore failed.\n");
           return -1;
       }
       else
       {
           rt_kprintf("create done. dynamic semaphore value = 0.\n");
       }

    /* 6050�߳� */
    rt_thread_t mpu6050_tid = RT_NULL;
    mpu6050_tid = rt_thread_create("thread_6050", thread_6050_entry, RT_NULL, 2048, 11, 5);
//    if(mpu6050_tid != RT_NULL)
    rt_thread_startup(mpu6050_tid);

    /* set LED2 pin mode to output */
    rt_pin_mode(LED2_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(LED2_PIN, PIN_HIGH);

    /* LED�߳� */
    rt_thread_t LED_tid = RT_NULL;
    LED_tid = rt_thread_create("thread_LED", rt_LED_entry, RT_NULL, 2048, 15, 5);





    while (count++)
    {
        AW_1 = AW;
        BW_1 = BW;
        mpu6xxx_get_gyro(i2c_bus, &gyro1);
        mpu6xxx_get_accel(i2c_bus, &accel1);
        gyro2 = gyro1.x/10;
        gyro3 = gyro1.y/10;
        gyro4 = gyro1.z/10;
        accel2 = accel1.x;
        accel3 = accel1.y;
        accel4 = accel1.z;
        AW = sqrt(accel2^2+accel3^2+accel4^2);
        BW = sqrt(gyro2^2+gyro3^2+gyro4^2);
//        CHA_AW = abs(AW-AW_1);
//        CHA_BW = abs(BW-BW_1);//��ƽ����
//        rt_kprintf("CHA_AW:%d \n",CHA_AW);
//        rt_kprintf("CHA_BW:%d \n",CHA_BW);
//        rt_kprintf("AW:%d \n",AW);
//        rt_kprintf("BW:%d \n",BW);
//        rt_kprintf("\n");rt_kprintf("\n");
        if((AW > 25)&&(BW > 10))
        {
//            LED_sem = 1;

            if(LED_tid != RT_NULL)
                    rt_thread_startup(LED_tid);
            rt_kprintf("111 \n");

        }

//        LOG_D("gyroX:%d",gyro2);
//        LOG_D("accelX:%d",gyro3);
//        LOG_D("gyroX:%d",gyro4);
//        LOG_D("accelX:%d",accel2);
//        LOG_D("gyroX:%d",accel3);
//        LOG_D("accelX:%d",accel4);
//        rt_kprintf("\n");
        rt_thread_mdelay(500);
    }
        return RT_EOK;
}
