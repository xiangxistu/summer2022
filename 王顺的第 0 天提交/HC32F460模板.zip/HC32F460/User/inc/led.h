#ifndef __LED_H__
#define __LED_H__
#include "main.h"

/* GREEN_LED Port/Pin definition */
#define  GREEN_LED_PORT        (PortE)
#define  GREEN_LED_PIN         (Pin00)

/* RED_LED Port/Pin definition */
#define  RED_LED_PORT        (PortE)
#define  RED_LED_PIN         (Pin01)

/* toggle definition */
#define  GREEN_LED_TOGGLE()    (PORT_Toggle(GREEN_LED_PORT, GREEN_LED_PIN))
#define  RED_LED_TOGGLE()    (PORT_Toggle(RED_LED_PORT, RED_LED_PIN))

extern void Led_Init(void);
#endif
