#ifndef __USART_H__
#define __USART_H__
#include "main.h"
/* USART baudrate definition */
#define USART_BAUDRATE                  (115200ul)

/* USART channel definition */
#define USART_CH                        (M4_USART4)

/* USART RX Port/Pin definition */
#define USART_RX_PORT                   (PortC)
#define USART_RX_PIN                    (Pin07)
#define USART_RX_FUNC                   (Func_Usart4_Rx)

/* USART TX Port/Pin definition */
#define USART_TX_PORT                   (PortC)
#define USART_TX_PIN                    (Pin06)
#define USART_TX_FUNC                   (Func_Usart4_Tx)



#ifdef RT_USING_CONSOLE

extern int t_Usart_Init(void);
extern void rt_hw_console_output(const char *str);
extern char rt_hw_console_getchar(void);
#endif
#endif
