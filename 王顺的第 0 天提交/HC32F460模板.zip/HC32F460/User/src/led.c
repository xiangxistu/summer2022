#include "led.h"

void Led_Init(void)
{
	  stc_port_init_t stcPortInit;

    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stcPortInit);

    stcPortInit.enPinMode = Pin_Mode_Out;
    stcPortInit.enPullUp = Enable;

    /* GREEN_LED Port/Pin initialization */
    PORT_Init(GREEN_LED_PORT, GREEN_LED_PIN, &stcPortInit);

    /* RED_LED Port/Pin initialization */
    PORT_Init(RED_LED_PORT, RED_LED_PIN, &stcPortInit);
}
                                                                                     

