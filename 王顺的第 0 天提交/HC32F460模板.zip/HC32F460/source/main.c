#include "main.h"
//�����߳̿��ƿ�
static struct rt_thread test_thread;
//�����߳�ջ
static rt_uint8_t rt_test_thread_stack[512];
static void device_config(void);
static void test_thread_entry(void *parameter);

static void device_config(void)
{
		Led_Init();
}
static void test_thread_entry(void *parameter)
{
	while(1)
	{
			GREEN_LED_TOGGLE();
			rt_thread_mdelay(1000);
			RED_LED_TOGGLE();	
//			rt_kprintf("test thread \r\n"); 
	}
}
int32_t main(void)
{
	device_config();
	rt_thread_init(&test_thread,
									"test_thread",
									test_thread_entry,
									RT_NULL,
									&rt_test_thread_stack,
									sizeof(rt_test_thread_stack),
									5,
									0);	
	rt_thread_startup(&test_thread);
}
