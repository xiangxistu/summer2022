/*******************************************************************************
 * Copyright (C) 2020, Huada Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by HDSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 */
/******************************************************************************/
/** \file system_hc32f460.c
 **
 ** A detailed description is available at
 ** @link Hc32f460SystemGroup Hc32f460System description @endlink
 **
 **   - 2018-10-15 CDT First version
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "hc32_common.h"
#include "main.h"
/**
 *******************************************************************************
 ** \addtogroup Hc32f460SystemGroup
 ******************************************************************************/

/*******************************************************************************
 * Global pre-processor symbols/macros ('define')
 ******************************************************************************/

//@{

/**
 ******************************************************************************
 ** System Clock Frequency (Core Clock) Variable according CMSIS
 ******************************************************************************/
uint32_t HRC_VALUE = HRC_16MHz_VALUE;
uint32_t SystemCoreClock = MRC_VALUE;

/**
 ******************************************************************************
 ** \brief  Setup the microcontroller system. Initialize the System and update
 ** the SystemCoreClock variable.
 **
 ** \param  None
 ** \return None
 ******************************************************************************/
void SystemInit(void)
{
#if (__FPU_PRESENT == 1) && (__FPU_USED == 1)
    SCB->CPACR |= ((3UL << 20) | (3UL << 22)); /* set CP10 and CP11 Full Access */
#endif
    SystemCoreClockUpdate();	
}

void SystemCoreClockUpdate(void)  // Update SystemCoreClock variable
{
    uint8_t tmp = 0u;
    uint32_t plln = 19u, pllp = 1u, pllm = 0u, pllsource = 0u;

    /* Select proper HRC_VALUE according to ICG1.HRCFREQSEL bit */
    /* ICG1.HRCFREQSEL = '0' represent HRC_VALUE = 20000000UL   */
    /* ICG1.HRCFREQSEL = '1' represent HRC_VALUE = 16000000UL   */
    if (1UL == (HRC_FREQ_MON() & 1UL))
    {
        HRC_VALUE = HRC_16MHz_VALUE;
    }
    else
    {
        HRC_VALUE = HRC_20MHz_VALUE;
    }

    tmp = M4_SYSREG->CMU_CKSWR_f.CKSW;
    switch (tmp)
    {
        case 0x00:  /* use internal high speed RC */
            SystemCoreClock = HRC_VALUE;
            break;
        case 0x01:  /* use internal middle speed RC */
            SystemCoreClock = MRC_VALUE;
            break;
        case 0x02:  /* use internal low speed RC */
            SystemCoreClock = LRC_VALUE;
            break;
        case 0x03:  /* use external high speed OSC */
            SystemCoreClock = XTAL_VALUE;
            break;
        case 0x04:  /* use external low speed OSC */
            SystemCoreClock = XTAL32_VALUE;
            break;
        case 0x05:  /* use MPLL */
            /* PLLCLK = ((pllsrc / pllm) * plln) / pllp */
            pllsource = M4_SYSREG->CMU_PLLCFGR_f.PLLSRC;
            plln = M4_SYSREG->CMU_PLLCFGR_f.MPLLN;
            pllp = M4_SYSREG->CMU_PLLCFGR_f.MPLLP;
            pllm = M4_SYSREG->CMU_PLLCFGR_f.MPLLM;
            /* use exteranl high speed OSC as PLL source */
            if (0ul == pllsource)
            {
                SystemCoreClock = (XTAL_VALUE) / (pllm + 1ul) * (plln + 1ul) / (pllp + 1ul);
							            }
            /* use interanl high RC as PLL source */
            else if (1ul == pllsource)
            {
                SystemCoreClock = (HRC_VALUE) / (pllm + 1ul) * (plln + 1ul) / (pllp + 1ul);
            }
            else
            {
                /* Reserved */
            }
            break;
    }
}
void SysClkConfig(void)
{
    stc_clk_sysclk_cfg_t    stcSysClkCfg;  //ϵͳʱ��
    stc_clk_xtal_cfg_t      stcXtalCfg;    //��������
    stc_clk_mpll_cfg_t      stcMpllCfg;    //PLL
		stc_sram_config_t           stcSramConfig;
	
    MEM_ZERO_STRUCT(stcSysClkCfg);
    MEM_ZERO_STRUCT(stcXtalCfg);
    MEM_ZERO_STRUCT(stcMpllCfg);

    /* Set bus clk div.    ��Ƶ */
    stcSysClkCfg.enHclkDiv  = ClkSysclkDiv1;  // 100MHz  
    stcSysClkCfg.enExclkDiv = ClkSysclkDiv2;  // 50MHz
    stcSysClkCfg.enPclk0Div = ClkSysclkDiv1;  // 100MHz
    stcSysClkCfg.enPclk1Div = ClkSysclkDiv2;  // 50MHz
    stcSysClkCfg.enPclk2Div = ClkSysclkDiv4;  // 25MHz
    stcSysClkCfg.enPclk3Div = ClkSysclkDiv4;  // 25MHz
    stcSysClkCfg.enPclk4Div = ClkSysclkDiv2;  // 50MHz
    CLK_SysClkConfig(&stcSysClkCfg);//ʱ�ӷ�Ƶ

    /* Switch system clock source to MPLL. */
    /* Use Xtal as MPLL source. */
    stcXtalCfg.enMode        = ClkXtalModeOsc;//XTALģʽѡ��λ  0������ģʽ 1���ⲿʱ������ģʽ
    stcXtalCfg.enDrv         = ClkXtalLowDrv;/*XTAL��������ѡ��   00������������(����20~24MHz����)
																																	01������������(����16~20MHz����)
																																	10��С��������(����8~16MHz����)
																																	11����С��������(����4~8MHz����)*/
    stcXtalCfg.enFastStartup = Enable;/*XTAL��������������  
																				0����ֹ����������
																				1���������������� ��������������ʱ��XTAL�ȶ������Ӵ�λ�趨����ֹ���������������͹��ġ�*/
    CLK_XtalConfig(&stcXtalCfg);//CMU XTAL  ���üĴ���
    CLK_XtalCmd(Enable);//����CMU XTAL  ���ƼĴ�����XTALSTPλ 0��XTAL������ 1��ֹͣ��

    while(Set != CLK_GetFlagStatus(ClkFlagXTALRdy))
    {
        ;
    }

    /* MPLL config. */
    stcMpllCfg.pllmDiv = 1ul;//MPLL����ʱ�ӷ�Ƶϵ��
    stcMpllCfg.plln    =50ul;//MPLL��Ƶϵ��
    stcMpllCfg.PllpDiv = 4ul;
    stcMpllCfg.PllqDiv = 4ul;
    stcMpllCfg.PllrDiv = 4ul;
    CLK_SetPllSource(ClkPllSrcXTAL);//ʱ��Դѡ��  XTAL
    CLK_MpllConfig(&stcMpllCfg);//CMU MPLL ʱ�ӷ�Ƶ����
		
    /* flash read wait cycle setting */
    EFM_Unlock();
    EFM_SetLatency(5ul);
    EFM_Lock();
		
    /* sram init include read/write wait cycle setting */
    stcSramConfig.u8SramIdx = Sram12Idx | Sram3Idx | SramHsIdx | SramRetIdx;
    stcSramConfig.enSramRC = SramCycle2;
    stcSramConfig.enSramWC = SramCycle2;
    stcSramConfig.enSramEccMode = EccMode3;
    stcSramConfig.enSramEccOp = SramNmi;
    stcSramConfig.enSramPyOp = SramNmi;
    SRAM_Init(&stcSramConfig);		

    /* Enable MPLL. */
    CLK_MpllCmd(Enable);//���ڿ�ʼֹͣMPLL��0��MPLL������ʼ 1��MPLLֹͣ

    /* Wait MPLL ready. */
    while(Set != CLK_GetFlagStatus(ClkFlagMPLLRdy))
    {
        ;
    }
//    SystemCoreClock = (XTAL_VALUE) / (M4_SYSREG->CMU_PLLCFGR_f.MPLLM + 1ul) * (M4_SYSREG->CMU_PLLCFGR_f.MPLLN + 1ul) / (M4_SYSREG->CMU_PLLCFGR_f.MPLLP + 1ul);

    /* Switch system clock source to MPLL. */
    CLK_SetSysClkSource(CLKSysSrcMPLL);//CMU  ϵͳʱ��Դ�л��Ĵ���
																			 /* 0 0 0��ѡ��HRCʱ����Ϊϵͳʱ��     �ڲ�����
																					0 0 1��ѡ��MRCʱ����Ϊϵͳʱ��     �ڲ�����
																					0 1 0��ѡ��LRCʱ����Ϊϵͳʱ��     �ڲ�����
																					0 1 1��ѡ��XTALʱ����Ϊϵͳʱ��    �ⲿ����
																					1 0 0��ѡ��XTAL32ʱ����Ϊϵͳʱ��  �ⲿ����
																					1 0 1��ѡ��MPLL��Ϊϵͳʱ��        ��Ƶ
																					1 1 0����ֹ�趨
																					1 1 1����ֹ�趨
																			 */

}


/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
// stc_clk_sysclk_cfg_t        stcSysClkCfg;
//    // stc_clk_xtal_cfg_t          stcXtalCfg;      /* �����ⲿ Xtal */
//    // stc_clk_xtal32_cfg_t        stcXtal32Cfg;      /* �����ⲿ Xtal32 */
//    stc_clk_mpll_cfg_t          stcMpllCfg;
//    stc_sram_config_t           stcSramConfig;
//    #ifdef USE_USB
//    stc_clk_upll_cfg_t          stcUpllCfg;
//    #endif
//    
//    MEM_ZERO_STRUCT(stcSysClkCfg);
//    // MEM_ZERO_STRUCT(stcXtalCfg);
//    // MEM_ZERO_STRUCT(stcXtal32Cfg);
//    MEM_ZERO_STRUCT(stcMpllCfg);
//    MEM_ZERO_STRUCT(stcSramConfig);
//    
//    /* Set bus clk div. */
//    stcSysClkCfg.enHclkDiv = ClkSysclkDiv1;   // ��ǰ 128MHz����� 168MHz
//    stcSysClkCfg.enExclkDiv = ClkSysclkDiv2;  // ��ǰ 64MHz����� 84MHz
//    stcSysClkCfg.enPclk0Div = ClkSysclkDiv1;  // ��ǰ 128MHz����� 168MHz
//    stcSysClkCfg.enPclk1Div = ClkSysclkDiv2;  // ��ǰ 64MHz����� 84MHz
//    stcSysClkCfg.enPclk2Div = ClkSysclkDiv4;  // ��ǰ 32MHz����� 60MHz
//    stcSysClkCfg.enPclk3Div = ClkSysclkDiv4;  // ��ǰ 32MHz����� 42MHz
//    stcSysClkCfg.enPclk4Div = ClkSysclkDiv2;  // ��ǰ 64MHz����� 84MHz
//    CLK_SysClkConfig(&stcSysClkCfg);
//    
//    // /* XTAL������ */
//    // /* Use Xtal as MPLL source. */
//    // stcXtalCfg.enMode        = ClkXtalModeOsc;
//    // stcXtalCfg.enDrv         = ClkXtalMidDrv;
//    // stcXtalCfg.enFastStartup = Enable;
//    // CLK_XtalConfig(&stcXtalCfg);
//    // CLK_XtalCmd(Enable);

//    /* ���� HRC ���� PLL ����Ϊϵͳʱ�ӣ�������ֱ��ʹ�� HRC��HRC �ǿ���ֱ����Ϊϵͳʱ�ӣ� */

//    /* 1. ���� HRC�� MCU ������Ĭ���� MRC �����������¿�ʼ�л��� HRC */
//    CLK_HrcCmd(Enable);

//    /* �����ֲᣬ��Ҫ�ȴ� HRC Ready ��ſ�������ʹ�� */
//    while(Set != CLK_GetFlagStatus(ClkFlagHRCRdy));

//    /* 2. ���� PLL ��ʱ��ԴΪ HRC */
//    CLK_SetPllSource(ClkPllSrcHRC);

//    /* 3. MPLL config (������ / pllmDiv * plln / PllpDiv = 128M). */
//    stcMpllCfg.pllmDiv = 16ul;
//    stcMpllCfg.plln    = 256ul;
//    stcMpllCfg.PllpDiv = 2ul;
//    stcMpllCfg.PllqDiv = 8ul;
//    stcMpllCfg.PllrDiv = 2ul;
//    CLK_MpllConfig(&stcMpllCfg);
//    
//    /* Enable MPLL. */
//    CLK_MpllCmd(Enable);

//    /* flash read wait cycle setting */
//    EFM_Unlock();
//    EFM_SetLatency(EFM_LATENCY_3);
//    EFM_Lock();

//    /* sram init include read/write wait cycle setting */
//    stcSramConfig.u8SramIdx = Sram12Idx | Sram3Idx | SramHsIdx | SramRetIdx;
//    stcSramConfig.enSramRC = SramCycle2;
//    stcSramConfig.enSramWC = SramCycle2;
//    stcSramConfig.enSramEccMode = EccMode3;
//    stcSramConfig.enSramEccOp = SramNmi;
//    stcSramConfig.enSramPyOp = SramNmi;
//    SRAM_Init(&stcSramConfig);
//    
//    /* Wait MPLL ready. */
//    while(Set != CLK_GetFlagStatus(ClkFlagMPLLRdy));
//    
//    /* Switch system clock source to MPLL. */
//    CLK_SetSysClkSource(CLKSysSrcMPLL);
//    
//    #if (DDL_RTC_ENABLE == DDL_ON)
//    // CLK_LrcCmd(Enable);     //Enable LRC   for RTC

//    // /* RTC �� xtal32 */
//    // stcXtal32Cfg.enFastStartup = Disable;
//    // stcXtal32Cfg.enDrv = ClkXtal32HighDrv;
//    // stcXtal32Cfg.enFilterMode = ClkXtal32FilterModeFull;
//    // CLK_Xtal32Config(&stcXtal32Cfg);
//    // /* Startup xtal32 */
//    // CLK_Xtal32Cmd(Enable);
//    // /* wait for xtal32 running */
//    // Ddl_Delay1ms(3000u);
//    #endif

//    #if DDL_USBFS_ENABLE == DDL_ON
//    /* UPLL config (XTAL(��ǰΪ 6M) / pllmDiv * plln / PllpDiv = 48M). */
//    stcUpllCfg.pllmDiv = 6u;
//    stcUpllCfg.plln = 48u;
//    stcUpllCfg.PllpDiv = 1u;//48M
//    stcUpllCfg.PllqDiv = 1u;
//    stcUpllCfg.PllrDiv = 1u;
//    CLK_UpllConfig(&stcUpllCfg);
//    CLK_UpllCmd(Enable);
//    /* Wait UPLL ready. */
//    while(Set != CLK_GetFlagStatus(ClkFlagUPLLRdy))
//    {
//        ;
//    }

//    /* Set USB clock source */
//    CLK_SetUsbClkSource(ClkUsbSrcUpllp);
//    #endif
